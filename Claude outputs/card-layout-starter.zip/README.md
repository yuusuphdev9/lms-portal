# Responsive Card Layout — Starter Files

Starter files for the **Build a Responsive Card Layout** assignment.

## What's here

- `index.html` — six `.card` elements (image, title, description) inside a `.card-grid` container. Don't change this structure.
- `style.css` — a basic reset and card styling. The grid/flex layout is left for you to build.

## Your task

1. Open `style.css` and lay out `.card-grid` as a **3-column layout** using Flexbox or CSS Grid — your choice.
2. Below **640px** width, the layout should collapse to a **single column**. Use a media query for the breakpoint — not JavaScript.
3. Each card already has an image, a title, and a short description — style them so they look like cards (you already have a border, padding, and rounded corners to start from).

## Running it

No build step needed — just open `index.html` directly in a browser, or serve the folder with any static server (e.g. the VS Code "Live Server" extension, or `npx serve .`).
