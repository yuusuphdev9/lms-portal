import { useState } from 'react'

/**
 * Starter shell for the "Build a Todo List with useState" assignment.
 *
 * Your task:
 *   1. Let a user type a task into the input below.
 *   2. Add it to the list by pressing Enter OR clicking "Add".
 *   3. Clicking a todo toggles it complete (give it a strikethrough or similar).
 *   4. Each todo has a delete button that removes just that one.
 *
 * Keep the whole list in ONE useState array of objects, e.g.
 *   { id: string, text: string, completed: boolean }
 * Don't reach for anything heavier (no external state library) for this one.
 */
function App() {
  const [todos, setTodos] = useState([])
  const [draft, setDraft] = useState('')

  function handleAdd() {
    // TODO: if `draft` is non-empty, append a new todo object to `todos`
    // and clear `draft`.
  }

  function handleToggle(id) {
    // TODO: flip `completed` on the todo whose id matches, leave the rest alone.
  }

  function handleDelete(id) {
    // TODO: remove the todo whose id matches from `todos`.
  }

  return (
    <main className="todo-app">
      <h1>Todo List</h1>

      <div className="todo-input-row">
        <input
          type="text"
          placeholder="Add a task..."
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleAdd()
          }}
        />
        <button onClick={handleAdd}>Add</button>
      </div>

      <ul className="todo-list">
        {todos.map((todo) => (
          <li
            key={todo.id}
            className={todo.completed ? 'completed' : ''}
            onClick={() => handleToggle(todo.id)}
          >
            <span>{todo.text}</span>
            <button
              onClick={(e) => {
                e.stopPropagation()
                handleDelete(todo.id)
              }}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>

      {todos.length === 0 && <p className="empty-hint">No todos yet — add one above.</p>}
    </main>
  )
}

export default App
