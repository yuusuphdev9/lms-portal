# React Todo List — Starter

Starter shell for the **Build a Todo List with useState** assignment.

## Getting started

```bash
npm install
npm run dev
```

## What's already here

- An input + "Add" button, wired up to call `handleAdd()` on click or on Enter.
- A `todos` list rendered with a toggle-on-click and a per-item delete button.
- Three `TODO` functions in `src/App.jsx` — `handleAdd`, `handleToggle`, `handleDelete` — currently empty.

## Your task

Fill in the three `TODO` functions in `src/App.jsx`:

1. **`handleAdd`** — if `draft` is non-empty, append a new todo (`{ id, text, completed: false }`) to `todos`, then clear `draft`.
2. **`handleToggle(id)`** — flip `completed` on the todo whose `id` matches; leave the rest unchanged.
3. **`handleDelete(id)`** — remove the todo whose `id` matches from `todos`.

Keep the whole list in the single `todos` `useState` array already declared — no extra state library needed.
